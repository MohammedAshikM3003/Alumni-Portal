import { FC, useState, useEffect } from 'react';
import { useParams, Link, useLocation } from 'react-router-dom';
import styles from './Co_View_JobForm.module.css';
import Sidebar from './Components/Sidebar/Sidebar';
import Back from './Components/BackButton/Back';
import { useAuth } from '../../context/authContext/authContext';

const API_BASE = import.meta.env.VITE_API_URL;

const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} min${diffMins > 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    if (diffDays === 1) return 'Yesterday';
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

interface SubmittedBy {
    _id: string;
    name: string;
    profilePhoto?: string;
    jobRole?: string;
}

interface JobReference {
    _id: string;
    submittedBy?: SubmittedBy;
    role: string;
    companyName: string;
    createdAt: string;
    updatedAt: string;
    status: 'pending' | 'approved' | 'rejected';
    targetBranch: string;
    vacancies: number | string;
    location: string;
    workMode: string;
    link?: string;
}

interface CoordinatorViewJobFormProps {
    onLogout: () => void;
}

const CoordinatorViewJobForm: FC<CoordinatorViewJobFormProps> = ({ onLogout }) => {
    const { id } = useParams<{ id: string }>();
    const location = useLocation();
    const passedJobData = location.state?.jobData as JobReference | undefined;
    const { user } = useAuth();
    const [jobReference, setJobReference] = useState<JobReference | null>(passedJobData || null);
    const [loading, setLoading] = useState<boolean>(!passedJobData);
    const [error, setError] = useState<string | null>(null);
    const [updating, setUpdating] = useState<boolean>(false);

    const handleStatusUpdate = async (newStatus: 'approved' | 'rejected') => {
        if (!user?.token || !id) return;
        if (!window.confirm(`Are you sure you want to ${newStatus} this job reference?`)) return;

        setUpdating(true);
        try {
            const response = await fetch(`${API_BASE}/api/jobs/${id}/status`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${user.token}`,
                },
                body: JSON.stringify({ status: newStatus }),
            });

            const data = await response.json();
            if (data.success && data.jobReference) {
                alert(`Job reference ${newStatus} successfully!`);
                setJobReference(data.jobReference);
            } else {
                alert(data.message || 'Failed to update status');
            }
        } catch (err: any) {
            alert(err.message || 'Failed to update status');
        } finally {
            setUpdating(false);
        }
    };

    const getBorderClassByStatus = (status: string): string => {
        switch (status) {
            case 'approved':
                return styles.borderGreen;
            case 'rejected':
                return styles.borderRed;
            default:
                return styles.borderGrey;
        }
    };

    useEffect(() => {
      const controller = new AbortController();
        if (passedJobData) {
            setJobReference(passedJobData);
            setLoading(false);
            return;
        }
        const fetchJobReference = async (): Promise<void> => {
            if (!user?.token) {
                setError('Please login to view job reference');
                setLoading(false);
                return;
            }

            if (!id) {
                setError('Job reference ID not provided');
                setLoading(false);
                return;
            }

            try {
                const response = await fetch(`${API_BASE}/api/jobs/${id}`, {
              signal: controller.signal,
                    headers: {
                        Authorization: `Bearer ${user.token}`,
                    },
                });

                if (!response.ok) {
                    throw new Error('Failed to fetch job reference');
                }

                const data = await response.json();
                if (data.success && data.jobReference) {
                    setJobReference(data.jobReference);
                }
            } catch (err: any) {
            if (err.name === 'AbortError') return;
                setError(err.message || 'An unknown error occurred');
            } finally {
                setLoading(false);
            }
        };

        fetchJobReference();

      return () => controller.abort();
    }, [user, id]);

    if (loading) {
        return (
            <div className="bg-[#F8FAFC] font-display text-slate-900 h-screen flex overflow-hidden">
                <Sidebar currentView="job_and_reference" onLogout={onLogout} />
                <main className="flex-1 ml-[70px] h-screen flex flex-col overflow-hidden">
                    <div className="flex-1 flex items-center justify-center">
                        <p className="text-slate-500">Loading job reference...</p>
                    </div>
                </main>
            </div>
        );
    }

    if (error || !jobReference) {
        return (
            <div className="bg-[#F8FAFC] font-display text-slate-900 h-screen flex overflow-hidden">
                <Sidebar currentView="job_and_reference" onLogout={onLogout} />
                <main className="flex-1 ml-[70px] h-screen flex flex-col overflow-hidden">
                    <div className="sticky top-0 bg-[#F8FAFC] px-8 pt-6 pb-2 z-10 border-b border-slate-200">
                        <Back to={'/coordinator/job_and_reference'} />
                    </div>
                    <div className={`flex-1 overflow-y-auto ${styles.mainScrollable} p-8 bg-[#F8FAFC]`}>
                        <div className="flex-1 flex items-center justify-center">
                            <p className="text-red-500">{error || 'Job reference not found'}</p>
                        </div>
                    </div>
                </main>
            </div>
        );
    }

    return (
        <div className="bg-[#F8FAFC] font-display text-slate-900 h-screen flex overflow-hidden">
            {/* Sidebar */}
            <Sidebar currentView="job_and_reference" onLogout={onLogout} />
            {/* Main Content Area */}
            <main className="flex-1 ml-[70px] h-screen flex flex-col overflow-hidden">
                <div className="sticky top-0 bg-[#F8FAFC] px-8 pt-6 pb-2 z-10 border-b border-slate-200">
                    <Back to={'/coordinator/job_and_reference'} />
                </div>
                <div className={`flex-1 overflow-y-auto ${styles.mainScrollable} p-8 bg-[#F8FAFC]`}>

                    <div className="max-w-auto mx-auto">
                        <div className="flex justify-between items-center mb-8">
                            <h2 className="text-2xl font-bold text-slate-900">View Job Reference</h2>
                            <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${jobReference.status === 'approved' ? 'bg-green-100 text-green-700' : jobReference.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                {jobReference.status}
                            </span>
                        </div>

                        <div className={`bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mb-8 ${getBorderClassByStatus(jobReference.status)}`}>
                            <div className="p-8 pb-0">
                                {/* Alumni Section */}
                                <div className="mb-8 pb-8 border-b border-slate-200">
                                    <div className="flex items-center gap-4">
                                        <div>
                                            {jobReference.submittedBy?.profilePhoto ? (
                                                <img
                                                    src={jobReference.submittedBy.profilePhoto}
                                                    alt={jobReference.submittedBy?.name}
                                                    className="w-20 h-20 rounded-full object-cover border-2 border-slate-200"
                                                />
                                            ) : (
                                                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center text-white font-bold text-2xl border-2 border-slate-200">
                                                    {jobReference.submittedBy?.name?.charAt(0).toUpperCase() || 'A'}
                                                </div>
                                            )}
                                        </div>
                                        <div className="flex-1">
                                            <h3 className="text-lg font-bold text-slate-900">{jobReference.submittedBy?.name || 'Unknown'}</h3>
                                            <p className="text-sm text-slate-600">{jobReference.submittedBy?.jobRole || 'Not specified'}</p>
                                        </div>
                                        <Link
                                            to={`/coordinator/alumni/${jobReference.submittedBy?._id}`}
                                            className="text-orange-500 font-semibold hover:text-orange-600 hover:underline cursor-pointer transition-all"
                                        >
                                            View Alumni
                                        </Link>
                                    </div>
                                </div>

                                {/* Job Details Grid */}
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-y-10 gap-x-12">
                                    <div>
                                        <label className="block text-sm font-medium text-slate-500 mb-1.5 uppercase tracking-wider">Company Name</label>
                                        <p className="text-lg font-bold text-slate-900">{jobReference.companyName}</p>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-slate-500 mb-1.5 uppercase tracking-wider">Role / Position</label>
                                        <p className="text-lg font-bold text-slate-900">{jobReference.role}</p>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-slate-500 mb-1.5 uppercase tracking-wider">Target Branch / Department</label>
                                        <p className="text-lg font-bold text-slate-900">{jobReference.targetBranch}</p>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-slate-500 mb-1.5 uppercase tracking-wider">Number of Vacancies</label>
                                        <p className="text-lg font-bold text-slate-900">{String(jobReference.vacancies).padStart(2, '0')}</p>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-slate-500 mb-1.5 uppercase tracking-wider">Location</label>
                                        <p className="text-lg font-bold text-slate-900">{jobReference.location}</p>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-slate-500 mb-1.5 uppercase tracking-wider">Work Mode</label>
                                        <p className="text-lg font-bold text-slate-900 capitalize">{jobReference.workMode}</p>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-slate-500 mb-1.5 uppercase tracking-wider">Application Link</label>
                                        {jobReference.link ? (
                                            <a href={jobReference.link.startsWith('http') ? jobReference.link : `https://${jobReference.link}`} target="_blank" rel="noopener noreferrer" className="text-lg font-bold text-blue-600 hover:underline break-all">
                                                {jobReference.link}
                                            </a>
                                        ) : (
                                            <p className="text-lg font-bold text-slate-400 italic">Not provided</p>
                                        )}
                                    </div>
                                </div>
                            </div>
                            <div className="bg-slate-50 px-8 py-4 border-t border-slate-100">
                                <div className="flex items-center gap-2 text-slate-400 text-xs">
                                    <span className="material-symbols-outlined text-sm">info</span>
                                    Posted by {jobReference.submittedBy?.name || 'Alumni'} • Last updated {formatDate(jobReference.updatedAt)}
                                </div>
                            </div>
                        </div>

                        {/* Approval Actions Section */}
                        {jobReference.status === 'pending' && (
                            <div className="mt-8 p-6 bg-white rounded-2xl border border-slate-200 flex justify-end gap-4 shadow-sm">
                                <button
                                    onClick={() => handleStatusUpdate('rejected')}
                                    disabled={updating}
                                    className="px-5 py-2.5 rounded-xl border border-red-200 text-red-600 font-bold text-sm bg-white hover:bg-red-50 transition-colors disabled:opacity-50"
                                >
                                    Reject Referral
                                </button>
                                <button
                                    onClick={() => handleStatusUpdate('approved')}
                                    disabled={updating}
                                    className="px-5 py-2.5 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold text-sm transition-colors shadow-md shadow-green-600/10 disabled:opacity-50"
                                >
                                    {updating ? 'Updating...' : 'Approve Referral'}
                                </button>
                            </div>
                        )}

                    </div>
                </div>
            </main>
        </div>
    );
};

export default CoordinatorViewJobForm;
