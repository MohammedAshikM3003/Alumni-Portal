import { useState, useEffect } from "react";
import styles from "./Sidebar.module.css";
import { useNavigate } from 'react-router-dom';

const API_BASE = import.meta.env.VITE_API_URL;

interface SidebarProps {
  onLogout?: () => void;
  currentView?: string;
}

export default function Sidebar({ onLogout, currentView }: SidebarProps) {
  const navigate = useNavigate();
  const [logoUrl, setLogoUrl] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    const fetchBranding = async () => {
      try {
        const res = await fetch(`${API_BASE}/api/admin/branding`, {
          signal: controller.signal,
        });
        const data = await res.json();
        if (data.success && data.data?.logo) {
          setLogoUrl(`${API_BASE}${data.data.logo}`);
        }
      } catch (err: any) {
          if (err.name === 'AbortError') return;
        console.error('Failed to fetch branding:', err);
      }
    };
    fetchBranding();

    return () => controller.abort();
  }, []);

  const handleLogout = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onLogout) {
      onLogout();
    }
  };


  const handleNavClick = (e: React.MouseEvent, view: string) => {
    e.preventDefault();
    navigate(`/coordinator/${view}`);
  };

  return (
    <aside id="sidebar" className={styles.sidebar}>
      <div className={styles.sidebarHeader}>
        <img
          src={logoUrl || ''}
          alt="KSRCE Logo"
          className={styles.sidebarLogo}
        />
        <span className={styles.sidebarTitle}>
          Alumni Portal
        </span>
      </div>

      <nav className={styles.sidebarNav}>
        <a 
          className={`${styles.navLink} ${currentView === 'dashboard' ? styles.navLinkActive : ''} ${styles.dashboardLink}`} 
          href="#"
          onClick={(e) => handleNavClick(e, 'dashboard')}
        >
          <span className="material-symbols-outlined">dashboard</span>
          <span className={styles.navLinkText}>
            Dashboard
          </span>
        </a>
        <a 
          className={`${styles.navLink} ${currentView === 'mail' ? styles.navLinkActive : ''}`}
          onClick={(e) => handleNavClick(e, 'mail')}
        >
          <span className="material-symbols-outlined">mail</span>
          <span className={styles.navLinkText}>
            Mail
          </span>
        </a>
        <a className={`${styles.navLink} ${currentView === 'job_and_reference' ? styles.navLinkActive : ''}`}

        onClick={(e) => handleNavClick(e, 'job_and_reference')}>
          <span className="material-symbols-outlined">work</span>
          <span className={styles.navLinkText}>
            Job &amp; Reference
          </span>
        </a>
        <a
          className={`${styles.navLink} ${currentView === 'alumni' ? styles.navLinkActive : ''}`}
          onClick={(e) => handleNavClick(e, 'alumni')}
        >
          <span className="material-symbols-outlined">people</span>
          <span className={styles.navLinkText}>
            Alumni
          </span>
        </a>
        <a className={`${styles.navLink} ${currentView === 'donation_history' ? styles.navLinkActive : ''}`}
        onClick={(e) => handleNavClick(e, 'donation_history')}>
          <span className="material-symbols-outlined">volunteer_activism</span>
          <span className={styles.navLinkText}>
            Donation
          </span>
        </a>
        <a 
        className={`${styles.navLink} ${currentView === 'Events_and_Reunions' ? styles.navLinkActive : ''}`} 
        href="#"
        onClick={(e) => handleNavClick(e, 'invitations')}>
          <span className="material-symbols-outlined">event</span>
          <span className={styles.navLinkText}>
            Events and Reunions
          </span>
        </a>
        <a 
        className={`${styles.navLink} ${currentView === 'feedback' ? styles.navLinkActive : ''}`} 
        onClick={(e) => handleNavClick(e, 'feedback_history')}>
          <span className="material-symbols-outlined">feedback</span>
          <span className={styles.navLinkText}>
            Feedback
          </span>
        </a>
      </nav>

      <div className={styles.sidebarFooter}>
        <a className={`${styles.navLink} ${currentView === 'profile' ? styles.navLinkActive : ''}`} 
            onClick={(e) => handleNavClick(e, 'profile')}>
          <span className="material-symbols-outlined">account_circle</span>
          <span className={styles.navLinkText}>
            Profile
          </span>
        </a>
        <a 
          className={`${styles.navLink} ${styles.logoutLink}`} 
          href="#" 
          onClick={handleLogout}
          style={{ marginTop: '0.5rem' }}
        >
          <span className="material-symbols-outlined">logout</span>
          <span className={styles.navLinkText}>
            Logout
          </span>
        </a>
      </div>
    </aside>
  );
}